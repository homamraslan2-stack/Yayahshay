import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelType,
  ChatInputCommandInteraction,
  Client,
  EmbedBuilder,
  GuildMember,
  Message,
  MessageFlags,
  ModalSubmitInteraction,
  ModalBuilder,
  PermissionFlagsBits,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  TextChannel,
  TextInputBuilder,
  TextInputStyle,
  UserSelectMenuBuilder,
  UserSelectMenuInteraction,
} from "discord.js";
import { getGuildSettings } from "./config-store.js";
import { logError } from "./logger.js";

type TicketKind = "inquiry" | "purchase";

interface TicketMetadata {
  ownerId: string;
  staffRoleId: string;
  kind: TicketKind;
  claimedBy?: string;
}

const ticketPermissionSet = [
  PermissionFlagsBits.ViewChannel,
  PermissionFlagsBits.SendMessages,
  PermissionFlagsBits.ReadMessageHistory,
  PermissionFlagsBits.AttachFiles,
];

const MAX_TRANSCRIPT_MESSAGES = 5000;
const MAX_TRANSCRIPT_BYTES = 7_500_000;

export function ticketPanelButtons(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("ticket:open:inquiry")
      .setLabel("استفسار")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("ticket:open:purchase")
      .setLabel("شراء بوت")
      .setStyle(ButtonStyle.Success),
  );
}

function ticketControls(
  metadata: TicketMetadata,
): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("ticket:claim")
      .setLabel(metadata.claimedBy ? "مستلمة" : "استلام التذكرة")
      .setStyle(ButtonStyle.Success)
      .setDisabled(Boolean(metadata.claimedBy)),
    new ButtonBuilder()
      .setCustomId("ticket:settings")
      .setLabel("إعدادات التذكرة")
      .setStyle(ButtonStyle.Secondary),
  );
}

function encodeTicketTopic(metadata: TicketMetadata): string {
  return [
    "ticket-v1",
    `owner=${metadata.ownerId}`,
    `kind=${metadata.kind}`,
    `staff=${metadata.staffRoleId}`,
    `claimed=${metadata.claimedBy ?? ""}`,
  ].join("|");
}

function readTicketMetadata(channel: TextChannel): TicketMetadata | null {
  const topic = channel.topic;
  if (!topic?.startsWith("ticket-v1|")) return null;

  const fields = Object.fromEntries(
    topic
      .split("|")
      .slice(1)
      .map((field) => {
        const separator = field.indexOf("=");
        return [field.slice(0, separator), field.slice(separator + 1)];
      }),
  );

  if (
    !/^\d+$/.test(fields.owner ?? "") ||
    !/^\d+$/.test(fields.staff ?? "") ||
    (fields.kind !== "inquiry" && fields.kind !== "purchase")
  ) {
    return null;
  }

  return {
    ownerId: fields.owner,
    staffRoleId: fields.staff,
    kind: fields.kind,
    claimedBy: /^\d+$/.test(fields.claimed ?? "")
      ? fields.claimed
      : undefined,
  };
}

function ticketChannelFromInteraction(
  interaction:
    | ButtonInteraction
    | StringSelectMenuInteraction
    | UserSelectMenuInteraction
    | ModalSubmitInteraction
    | ChatInputCommandInteraction,
): TextChannel | null {
  const channel = interaction.channel;
  if (!channel || channel.type !== ChannelType.GuildText) return null;
  return channel;
}

async function replyEphemeral(
  interaction:
    | ButtonInteraction
    | StringSelectMenuInteraction
    | UserSelectMenuInteraction
    | ModalSubmitInteraction
    | ChatInputCommandInteraction,
  content: string,
): Promise<void> {
  if (interaction.deferred || interaction.replied) {
    await interaction.followUp({
      content,
      flags: MessageFlags.Ephemeral,
    });
  } else {
    await interaction.reply({
      content,
      flags: MessageFlags.Ephemeral,
    });
  }
}

async function hasTicketStaffAccess(
  interaction:
    | ButtonInteraction
    | StringSelectMenuInteraction
    | UserSelectMenuInteraction
    | ModalSubmitInteraction
    | ChatInputCommandInteraction,
  metadata: TicketMetadata,
): Promise<boolean> {
  if (!interaction.guild) return false;
  const member = await interaction.guild.members
    .fetch(interaction.user.id)
    .catch(() => null);
  return Boolean(
    member &&
      (member.roles.cache.has(metadata.staffRoleId) ||
        member.permissions.has(PermissionFlagsBits.Administrator)),
  );
}

async function validateTicketStaff(
  interaction:
    | ButtonInteraction
    | StringSelectMenuInteraction
    | UserSelectMenuInteraction
    | ModalSubmitInteraction
    | ChatInputCommandInteraction,
): Promise<{ channel: TextChannel; metadata: TicketMetadata } | null> {
  const channel = ticketChannelFromInteraction(interaction);
  const metadata = channel ? readTicketMetadata(channel) : null;
  if (!channel || !metadata) {
    await replyEphemeral(interaction, "هذا الزر يعمل داخل قناة تذكرة فقط.");
    return null;
  }
  if (!(await hasTicketStaffAccess(interaction, metadata))) {
    await replyEphemeral(interaction, "هذا الإجراء مخصص لفريق الدعم.");
    return null;
  }
  return { channel, metadata };
}

function renameTicketModal(): ModalBuilder {
  const input = new TextInputBuilder()
    .setCustomId("ticket-name")
    .setLabel("الاسم الجديد للقناة")
    .setStyle(TextInputStyle.Short)
    .setMinLength(1)
    .setMaxLength(90)
    .setRequired(true);
  return new ModalBuilder()
    .setCustomId("ticket:modal:rename")
    .setTitle("تغيير اسم التذكرة")
    .addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(input));
}

function closeTicketModal(): ModalBuilder {
  const input = new TextInputBuilder()
    .setCustomId("close-reason")
    .setLabel("سبب إغلاق التذكرة")
    .setStyle(TextInputStyle.Paragraph)
    .setMinLength(3)
    .setMaxLength(1000)
    .setRequired(true);
  return new ModalBuilder()
    .setCustomId("ticket:modal:close")
    .setTitle("إغلاق التذكرة")
    .addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(input));
}

function safeChannelName(value: string): string {
  const normalized = value
    .normalize("NFC")
    .toLowerCase()
    .trim()
    .replace(/[^\p{L}\p{M}\p{N}_-]+/gu, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 90);
  return normalized || `ticket-${Date.now().toString().slice(-8)}`;
}

async function openTicket(
  client: Client,
  interaction: ButtonInteraction,
  kind: TicketKind,
): Promise<void> {
  const guild = interaction.guild;
  if (!guild) {
    await replyEphemeral(interaction, "لا يمكن فتح تذكرة خارج السيرفر.");
    return;
  }

  const settings = await getGuildSettings(guild.id);
  const ticketSettings = settings.ticket;
  if (!ticketSettings || ticketSettings.panelChannelId !== interaction.channelId) {
    await replyEphemeral(
      interaction,
      "لوحة التذاكر قديمة أو لم تعد مفعّلة؛ أخبر مسؤول السيرفر بإعدادها مجددًا.",
    );
    return;
  }

  const staffRole = guild.roles.cache.get(ticketSettings.staffRoleId);
  if (!staffRole) {
    await replyEphemeral(
      interaction,
      "رتبة فريق الدعم غير موجودة. أعد إعداد لوحة التذاكر.",
    );
    return;
  }

  const existing = guild.channels.cache.find((channel) => {
    if (channel.type !== ChannelType.GuildText) return false;
    return readTicketMetadata(channel)?.ownerId === interaction.user.id;
  });
  if (existing) {
    await replyEphemeral(interaction, `لديك تذكرة مفتوحة بالفعل: ${existing}`);
    return;
  }

  const panelChannel = await guild.channels
    .fetch(ticketSettings.panelChannelId)
    .catch(() => null);
  const parentId =
    panelChannel?.type === ChannelType.GuildText
      ? (panelChannel.parentId ?? undefined)
      : undefined;
  const metadata: TicketMetadata = {
    ownerId: interaction.user.id,
    staffRoleId: ticketSettings.staffRoleId,
    kind,
  };
  const kindLabel = kind === "inquiry" ? "استفسار" : "شراء بوت";
  const username = safeChannelName(interaction.user.username);
  const name = safeChannelName(`ticket-${kind}-${username}`);

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const channel = await guild.channels.create({
    name,
    type: ChannelType.GuildText,
    parent: parentId,
    topic: encodeTicketTopic(metadata),
    reason: `تذكرة ${kindLabel} بواسطة ${interaction.user.tag}`,
    permissionOverwrites: [
      {
        id: guild.roles.everyone.id,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: interaction.user.id,
        allow: ticketPermissionSet,
      },
      {
        id: staffRole.id,
        allow: ticketPermissionSet,
      },
      ...(client.user
        ? [
            {
              id: client.user.id,
              allow: [
                ...ticketPermissionSet,
                PermissionFlagsBits.ManageChannels,
              ],
            },
          ]
        : []),
    ],
  });

  try {
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`تذكرة ${kindLabel}`)
      .setDescription(ticketSettings.description)
      .addFields({
        name: "صاحب التذكرة",
        value: `<@${interaction.user.id}>`,
        inline: true,
      });
    await channel.send({
      content: `<@&${staffRole.id}> | <@${interaction.user.id}>`,
      embeds: [embed],
      components: [ticketControls(metadata)],
      allowedMentions: {
        parse: [],
        roles: [staffRole.id],
        users: [interaction.user.id],
      },
    });
  } catch (error) {
    await channel.delete("تعذر إرسال رسالة التذكرة الأولى").catch(() => null);
    throw error;
  }

  await interaction.editReply(`تم فتح تذكرتك: ${channel}`);
}

async function claimTicket(
  interaction: ButtonInteraction,
  channel: TextChannel,
  metadata: TicketMetadata,
): Promise<void> {
  if (metadata.claimedBy) {
    await replyEphemeral(
      interaction,
      `هذه التذكرة مستلمة بالفعل من قبل <@${metadata.claimedBy}>.`,
    );
    return;
  }

  metadata.claimedBy = interaction.user.id;
  await channel.setTopic(encodeTicketTopic(metadata));
  await interaction.update({
    components: [ticketControls(metadata)],
  });
  await channel.send({
    content: `تم استلام تذكرتك من قبل <@${interaction.user.id}>.`,
    allowedMentions: { parse: [], users: [interaction.user.id] },
  });
}

async function showSettingsMenu(
  interaction: ButtonInteraction,
): Promise<void> {
  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("ticket:settings:choose")
      .setPlaceholder("اختر إجراءً على التذكرة")
      .addOptions(
        {
          label: "تغيير اسم التذكرة",
          value: "rename",
          description: "تعديل اسم قناة التذكرة",
        },
        {
          label: "إضافة عضو",
          value: "add-member",
          description: "منح عضو صلاحية مشاهدة التذكرة والرد فيها",
        },
        {
          label: "إزالة عضو",
          value: "remove-member",
          description: "منع عضو من مشاهدة التذكرة",
        },
        {
          label: "إغلاق التذكرة",
          value: "close",
          description: "إرسال سجلها لصاحبها ثم حذف القناة",
        },
      ),
  );
  await interaction.reply({
    content: "إعدادات هذه التذكرة:",
    components: [row],
    flags: MessageFlags.Ephemeral,
  });
}

function userPicker(
  action: "add" | "remove",
): ActionRowBuilder<UserSelectMenuBuilder> {
  return new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(
    new UserSelectMenuBuilder()
      .setCustomId(`ticket:member:${action}`)
      .setPlaceholder(action === "add" ? "اختر العضو لإضافته" : "اختر العضو لإزالته")
      .setMinValues(1)
      .setMaxValues(1),
  );
}

async function handleSettingsChoice(
  interaction: StringSelectMenuInteraction,
): Promise<void> {
  const validated = await validateTicketStaff(interaction);
  if (!validated) return;

  switch (interaction.values[0]) {
    case "rename":
      await interaction.showModal(renameTicketModal());
      return;
    case "add-member":
      await interaction.reply({
        content: "اختر العضو الذي تريد إضافته:",
        components: [userPicker("add")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    case "remove-member":
      await interaction.reply({
        content: "اختر العضو الذي تريد إزالته:",
        components: [userPicker("remove")],
        flags: MessageFlags.Ephemeral,
      });
      return;
    case "close":
      await interaction.showModal(closeTicketModal());
      return;
    default:
      await replyEphemeral(interaction, "الإجراء غير معروف.");
  }
}

async function handleMemberChoice(
  interaction: UserSelectMenuInteraction,
  action: "add" | "remove",
): Promise<void> {
  const validated = await validateTicketStaff(interaction);
  if (!validated) return;
  const { channel, metadata } = validated;
  const targetId = interaction.values[0];

  if (action === "add") {
    await channel.permissionOverwrites.edit(targetId, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
      AttachFiles: true,
    });
    await interaction.reply({
      content: `تمت إضافة <@${targetId}> إلى التذكرة.`,
      allowedMentions: { parse: [], users: [targetId] },
      flags: MessageFlags.Ephemeral,
    });
    await channel.send({
      content: `أضاف فريق الدعم <@${targetId}> إلى التذكرة.`,
      allowedMentions: { parse: [], users: [targetId] },
    });
    return;
  }

  if (targetId === metadata.ownerId) {
    await replyEphemeral(interaction, "لا يمكن إزالة صاحب التذكرة منها.");
    return;
  }

  const targetMember = await interaction.guild?.members
    .fetch(targetId)
    .catch(() => null);
  if (
    targetMember?.roles.cache.has(metadata.staffRoleId) ||
    targetMember?.permissions.has(PermissionFlagsBits.Administrator)
  ) {
    await replyEphemeral(interaction, "لا يمكن إزالة عضو من فريق إدارة التذكرة.");
    return;
  }

  await channel.permissionOverwrites.edit(targetId, {
    ViewChannel: false,
    SendMessages: false,
    ReadMessageHistory: false,
    AttachFiles: false,
  });
  await interaction.reply({
    content: `تمت إزالة <@${targetId}> من التذكرة.`,
    allowedMentions: { parse: [], users: [targetId] },
    flags: MessageFlags.Ephemeral,
  });
  await channel.send({
    content: `أزال فريق الدعم <@${targetId}> من التذكرة.`,
    allowedMentions: { parse: [], users: [targetId] },
  });
}

function readableMessage(message: Message): string {
  const timestamp = new Date(message.createdTimestamp).toISOString();
  const author = `${message.author.tag} (${message.author.id})`;
  const lines = [`[${timestamp}] ${author}: ${message.content || "[بدون نص]"}`];

  for (const attachment of message.attachments.values()) {
    lines.push(`  مرفق: ${attachment.name ?? "ملف"} — ${attachment.url}`);
  }
  for (const embed of message.embeds) {
    if (embed.title) lines.push(`  عنوان: ${embed.title}`);
    if (embed.description) lines.push(`  محتوى مضمّن: ${embed.description}`);
  }

  return lines.join("\n");
}

async function createTranscript(
  channel: TextChannel,
): Promise<{ buffer: Buffer; truncated: boolean }> {
  const messages: Message[] = [];
  let before: string | undefined;
  let truncated = false;

  while (messages.length < MAX_TRANSCRIPT_MESSAGES) {
    const batch = await channel.messages.fetch({
      limit: 100,
      ...(before ? { before } : {}),
    });
    if (batch.size === 0) break;

    messages.push(...batch.values());
    const oldest = [...batch.values()].reduce((current, candidate) =>
      candidate.createdTimestamp < current.createdTimestamp ? candidate : current,
    );
    before = oldest.id;

    if (batch.size < 100) break;
  }

  if (messages.length >= MAX_TRANSCRIPT_MESSAGES) truncated = true;
  messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);

  const lines = [
    `سجل التذكرة: #${channel.name}`,
    `معرّف القناة: ${channel.id}`,
    `عدد الرسائل المسجلة: ${messages.length}`,
    "",
  ];
  let byteLength = Buffer.byteLength(lines.join("\n"), "utf8");

  for (const message of messages) {
    const line = `${readableMessage(message)}\n\n`;
    const nextLength = Buffer.byteLength(line, "utf8");
    if (byteLength + nextLength > MAX_TRANSCRIPT_BYTES) {
      truncated = true;
      break;
    }
    lines.push(line);
    byteLength += nextLength;
  }

  if (truncated) {
    lines.push("\n[تم اختصار السجل بسبب تجاوز الحد الآمن لحجم الملف.]");
  }
  return { buffer: Buffer.from(lines.join("\n"), "utf8"), truncated };
}

async function closeTicket(
  client: Client,
  interaction: import("discord.js").ModalSubmitInteraction,
  channel: TextChannel,
  metadata: TicketMetadata,
): Promise<void> {
  const reason = interaction.fields.getTextInputValue("close-reason").trim();
  if (reason.length < 3) {
    await replyEphemeral(interaction, "اكتب سببًا واضحًا لإغلاق التذكرة.");
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const owner = await client.users.fetch(metadata.ownerId).catch(() => null);
  if (!owner) {
    await interaction.editReply(
      "تعذر العثور على صاحب التذكرة؛ لم تُحذف القناة حفاظًا على محتواها.",
    );
    return;
  }

  const { buffer, truncated } = await createTranscript(channel);
  const claimer = metadata.claimedBy
    ? `<@${metadata.claimedBy}>`
    : "لم يستلمها أحد";
  const closer = `<@${interaction.user.id}>`;
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle("تم إغلاق تذكرتك")
    .setDescription(
      [
        `**نوع التذكرة:** ${metadata.kind === "inquiry" ? "استفسار" : "شراء بوت"}`,
        `**سبب الإغلاق:** ${reason}`,
        `**استلمها:** ${claimer}`,
        `**أغلقها:** ${closer}`,
      ].join("\n"),
    )
    .setFooter({
      text: truncated
        ? "تم اختصار سجل المحادثة إلى الحد الآمن لحجم الملف."
        : "أُرفق سجل المحادثة كاملًا.",
    });

  try {
    await owner.send({
      embeds: [embed],
      files: [
        new AttachmentBuilder(buffer, {
          name: `transcript-${channel.id}.txt`,
        }),
      ],
      allowedMentions: { parse: [] },
    });
  } catch (error) {
    logError("Could not DM the ticket transcript; keeping the ticket channel.", {
      error,
      channelId: channel.id,
      ownerId: owner.id,
    });
    await interaction.editReply(
      "لم أستطع إرسال السجل إلى الخاص. لم تُحذف القناة؛ افتح الرسائل الخاصة وحاول الإغلاق مرة أخرى.",
    );
    return;
  }

  await channel.delete(`أغلقت بواسطة ${interaction.user.tag}: ${reason}`);
  await interaction.editReply("تم إرسال السجل لصاحب التذكرة وحذف القناة.");
}

export async function handleTicketButton(
  client: Client,
  interaction: ButtonInteraction,
): Promise<boolean> {
  if (interaction.customId.startsWith("ticket:open:")) {
    const kind = interaction.customId.slice("ticket:open:".length);
    if (kind !== "inquiry" && kind !== "purchase") {
      await replyEphemeral(interaction, "نوع التذكرة غير معروف.");
      return true;
    }
    await openTicket(client, interaction, kind);
    return true;
  }

  if (interaction.customId !== "ticket:claim" &&
      interaction.customId !== "ticket:settings") {
    return false;
  }

  const validated = await validateTicketStaff(interaction);
  if (!validated) return true;

  if (interaction.customId === "ticket:claim") {
    await claimTicket(interaction, validated.channel, validated.metadata);
  } else {
    await showSettingsMenu(interaction);
  }
  return true;
}

export async function handleTicketSettingsSelect(
  interaction: StringSelectMenuInteraction,
): Promise<boolean> {
  if (interaction.customId !== "ticket:settings:choose") return false;
  await handleSettingsChoice(interaction);
  return true;
}

export async function handleTicketMemberSelect(
  interaction: UserSelectMenuInteraction,
): Promise<boolean> {
  if (interaction.customId !== "ticket:member:add" &&
      interaction.customId !== "ticket:member:remove") {
    return false;
  }
  await handleMemberChoice(
    interaction,
    interaction.customId === "ticket:member:add" ? "add" : "remove",
  );
  return true;
}

export async function handleTicketModal(
  client: Client,
  interaction: import("discord.js").ModalSubmitInteraction,
): Promise<boolean> {
  if (
    interaction.customId !== "ticket:modal:rename" &&
    interaction.customId !== "ticket:modal:close"
  ) {
    return false;
  }

  const validated = await validateTicketStaff(interaction);
  if (!validated) return true;
  const { channel, metadata } = validated;

  if (interaction.customId === "ticket:modal:rename") {
    const name = safeChannelName(
      interaction.fields.getTextInputValue("ticket-name"),
    );
    await channel.setName(name);
    await replyEphemeral(interaction, `تم تغيير اسم التذكرة إلى #${name}.`);
    return true;
  }

  await closeTicket(client, interaction, channel, metadata);
  return true;
}

export function ticketTypeLabel(kind: TicketKind): string {
  return kind === "inquiry" ? "استفسار" : "شراء بوت";
}