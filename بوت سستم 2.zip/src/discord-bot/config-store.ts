import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

export interface TicketSettings {
  panelChannelId: string;
  staffRoleId: string;
  description: string;
}

export interface AutoReplySettings {
  channelId: string;
  message: string;
}

export interface WelcomeSettings {
  channelId: string;
  message: string;
}

export interface GuildSettings {
  ticket?: TicketSettings;
  autoReply?: AutoReplySettings;
  autoRoleId?: string;
  welcome?: WelcomeSettings;
}

type ConfigFile = Record<string, GuildSettings>;

const configPath = fileURLToPath(
  new URL("../../data/discord-config.json", import.meta.url),
);

let config: ConfigFile | undefined;
let pendingWrite: Promise<void> = Promise.resolve();

async function loadConfig(): Promise<ConfigFile> {
  if (config) return config;

  try {
    config = JSON.parse(await readFile(configPath, "utf8")) as ConfigFile;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
      throw new Error("تعذرت قراءة ملف إعدادات البوت.", { cause: error });
    }
    config = {};
  }

  return config;
}

export async function getGuildSettings(
  guildId: string,
): Promise<GuildSettings> {
  const current = await loadConfig();
  return { ...(current[guildId] ?? {}) };
}

export async function updateGuildSettings(
  guildId: string,
  update: (settings: GuildSettings) => void,
): Promise<GuildSettings> {
  const current = await loadConfig();
  const settings = { ...(current[guildId] ?? {}) };
  update(settings);
  current[guildId] = settings;

  const serialized = JSON.stringify(current, null, 2);
  pendingWrite = pendingWrite.then(async () => {
    await mkdir(dirname(configPath), { recursive: true });
    const temporaryPath = `${configPath}.${process.pid}.tmp`;
    await writeFile(temporaryPath, serialized, "utf8");
    await rename(temporaryPath, configPath);
  });
  await pendingWrite;

  return { ...settings };
}