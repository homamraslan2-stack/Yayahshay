import {
  ChannelType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  MessageFlags,
  PermissionFlagsBits,
  Role,
  TextChannel,
} from "discord.js";
import { slashCommands } from "./commands.js";
import {
  getGuildSettings,
  updateGuildSettings,
} from "./config-store.js";
import { logError, logInfo, logWarn } from "./logger.js";
import {
  handleTicketButton,
  handleTicketMemberSelect,
  handleTicketModal,
  handleTicketSettingsSelect,
  ticketPanelButtons,
} from "./tickets.js";

interface LocalBotConfig {
  token?: string;
}

async function resolveBotToken(): Promise<string> {
  const environmentToken = process.env.DISCORD_BOT_TOKEN?.trim();
  let fileToken: string | undefined;

  try {
    const configModule = (await import(
      new URL("../../config.js", import.meta.url).href
    )) as { default?: LocalBotConfig };
    fileToken = configModule.default?.token?.trim();
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ERR_MODULE_NOT_FOUND") {
      throw error;
    }
  }

  const token = environmentToken || fileToken;
  if (token && token !== "PASTE_YOUR_DISCORD_BOT_TOKEN_HERE") return token;
  throw new Error(
    "رمز البوت غير موجود. أضفه في DISCORD_BOT_TOKEN أو في config.js.",
  );
}

const token = await resolveBotToken();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

async function isAdministrator(
  interaction: import("discord.js").ChatInputCommandInteraction,
): Promise<boolean> {
  if (!interaction.guild) return false;
  const member = await interaction.guild.members
    .fetch(interaction.user.id)
    .catch(() => null);
  return Boolean(member?.permissions.has(PermissionFlagsBits.Administrator));
}

async function handleCommand(
  interaction: import("discord.js").ChatInputCommandInteraction,
): Promise<void> {
  if (!interaction.guild) {
    await interaction.reply({
      content: "هذا الأمر يعمل داخل السيرفر فقط.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!(await isAdministrator(interaction))) {
    await interaction.reply({
      content: "هذه الأوامر مخصصة لمسؤولي السيرفر.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const guildId = interaction.guild.id;
  switch (interaction.commandName) {
    case "ticket-setup": {
      const channel = interaction.options.getChannel(
        "channel",
        true,
        [ChannelType.GuildText],
      ) as TextChannel;
      const staffRole = interaction.options.getRole("admin-role", true) as Role;
      const description = interaction.options.getString("description", true);

      await channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0x5865f2)
            .setTitle("الدعم الفني")
            .setDescription(description),
        ],
        components: [ticketPanelButtons()],
      });
      await updateGuildSettings(guildId, (current) => {
        current.ticket = {
          panelChannelId: channel.id,
          staffRoleId: staffRole.id,
          description,
        };
      });
      await interaction.reply({
        content: `تم إعداد لوحة التذاكر في ${channel}، وستصل إشعاراتها إلى ${staffRole}.`,
        flags: MessageFlags.Ephemeral,
        allowedMentions: { parse: [] },
      });
      return;
    }
    case "reply-setup": {
      const channel = interaction.options.getChannel(
        "channel",
        true,
        [ChannelType.GuildText],
      );
      const message = interaction.options.getString("message", true);
      await updateGuildSettings(guildId, (current) => {
        current.autoReply = { channelId: channel.id, message };
      });
      await interaction.reply({
        content: `تم تفعيل الرد التلقائي في ${channel}.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    case "reply-clear":
      await updateGuildSettings(guildId, (current) => {
        delete current.autoReply;
      });
      await interaction.reply({
        content: "تم إيقاف الرد التلقائي.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    case "autorole-setup": {
      const role = interaction.options.getRole("role", true);
      await updateGuildSettings(guildId, (current) => {
        current.autoRoleId = role.id;
      });
      await interaction.reply({
        content: `تم تحديد ${role} كرتبة تلقائية للأعضاء الجدد.`,
        flags: MessageFlags.Ephemeral,
        allowedMentions: { parse: [] },
      });
      return;
    }
    case "autorole-clear":
      await updateGuildSettings(guildId, (current) => {
        delete current.autoRoleId;
      });
      await interaction.reply({
        content: "تم إيقاف الرتبة التلقائية.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    case "welcome-setup": {
      const channel = interaction.options.getChannel(
        "channel",
        true,
        [ChannelType.GuildText],
      );
      const message = interaction.options.getString("message", true);
      await updateGuildSettings(guildId, (current) => {
        current.welcome = { channelId: channel.id, message };
      });
      await interaction.reply({
        content: `تم إعداد الترحيب في ${channel}. المتغيرات المتاحة: {user} و{username} و{server} و{memberCount}.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    case "welcome-clear":
      await updateGuildSettings(guildId, (current) => {
        delete current.welcome;
      });
      await interaction.reply({
        content: "تم إيقاف رسائل الترحيب.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    case "ticket-clear":
      await updateGuildSettings(guildId, (current) => {
        delete current.ticket;
      });
      await interaction.reply({
        content: "تم إيقاف لوحة التذاكر. التذاكر المفتوحة سابقًا تبقى قابلة للإدارة.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    case "setup-status": {
      const current = await getGuildSettings(guildId);
      const lines = [
        `**التذاكر:** ${current.ticket ? `<#${current.ticket.panelChannelId}> — <@&${current.ticket.staffRoleId}>` : "غير مفعّلة"}`,
        `**الرد التلقائي:** ${current.autoReply ? `<#${current.autoReply.channelId}>` : "غير مفعّل"}`,
        `**الرتبة التلقائية:** ${current.autoRoleId ? `<@&${current.autoRoleId}>` : "غير مفعّلة"}`,
        `**الترحيب:** ${current.welcome ? `<#${current.welcome.channelId}>` : "غير مفعّل"}`,
      ];
      await interaction.reply({
        content: lines.join("\n"),
        flags: MessageFlags.Ephemeral,
        allowedMentions: { parse: [] },
      });
      return;
    }
    default:
      await interaction.reply({
        content: "الأمر غير معروف.",
        flags: MessageFlags.Ephemeral,
      });
  }
}

function fillWelcomeTemplate(
  template: string,
  member: import("discord.js").GuildMember,
): string {
  return template
    .replaceAll("{user}", `<@${member.id}>`)
    .replaceAll("{member}", `<@${member.id}>`)
    .replaceAll("{username}", member.user.username)
    .replaceAll("{server}", member.guild.name)
    .replaceAll("{memberCount}", String(member.guild.memberCount))
    .replaceAll("{count}", String(member.guild.memberCount));
}

async function onMemberJoin(
  member: import("discord.js").GuildMember,
): Promise<void> {
  const settings = await getGuildSettings(member.guild.id);
  if (settings.autoRoleId) {
    try {
      await member.roles.add(
        settings.autoRoleId,
        "إعطاء الرتبة التلقائية للعضو الجديد",
      );
    } catch (error) {
      logError("Could not assign the configured automatic role.", {
        guildId: member.guild.id,
        memberId: member.id,
        roleId: settings.autoRoleId,
        error,
      });
    }
  }

  if (!settings.welcome) return;
  const channel = await member.guild.channels
    .fetch(settings.welcome.channelId)
    .catch(() => null);
  if (!channel || channel.type !== ChannelType.GuildText) {
    logWarn("Configured welcome channel is missing or is not a text channel.", {
      guildId: member.guild.id,
      channelId: settings.welcome.channelId,
    });
    return;
  }

  const message = fillWelcomeTemplate(settings.welcome.message, member);
  await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle("مرحبًا بك!")
        .setDescription(message),
    ],
    allowedMentions: { parse: [], users: [member.id] },
  });
}

async function onMessageCreate(
  message: import("discord.js").Message,
): Promise<void> {
  if (!message.guild || message.author.bot) return;
  const settings = await getGuildSettings(message.guild.id);
  if (
    settings.autoReply?.channelId !== message.channelId ||
    !message.channel.isSendable()
  ) {
    return;
  }

  await message.channel.send({
    content: settings.autoReply.message,
    allowedMentions: { parse: [] },
  });
}

client.once(Events.ClientReady, async (readyClient) => {
  logInfo("Discord bot connected.", {
    botTag: readyClient.user.tag,
    guildCount: readyClient.guilds.cache.size,
  });

  for (const guild of readyClient.guilds.cache.values()) {
    try {
      await guild.commands.set(slashCommands);
      logInfo("Registered slash commands for guild.", { guildId: guild.id });
    } catch (error) {
      logError("Could not register slash commands for guild.", {
        guildId: guild.id,
        error,
      });
    }
  }
});

client.on(Events.GuildCreate, async (guild) => {
  try {
    await guild.commands.set(slashCommands);
    logInfo("Registered slash commands for newly joined guild.", {
      guildId: guild.id,
    });
  } catch (error) {
    logError("Could not register slash commands for newly joined guild.", {
      guildId: guild.id,
      error,
    });
  }
});

client.on(Events.GuildMemberAdd, (member) => {
  void onMemberJoin(member).catch((error: unknown) => {
    logError("Could not finish the new member welcome flow.", {
      guildId: member.guild.id,
      memberId: member.id,
      error,
    });
  });
});

client.on(Events.MessageCreate, (message) => {
  void onMessageCreate(message).catch((error: unknown) => {
    logError("Could not send an automatic reply.", {
      guildId: message.guildId,
      channelId: message.channelId,
      error,
    });
  });
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      await handleCommand(interaction);
      return;
    }
    if (interaction.isButton()) {
      await handleTicketButton(client, interaction);
      return;
    }
    if (interaction.isStringSelectMenu()) {
      await handleTicketSettingsSelect(interaction);
      return;
    }
    if (interaction.isUserSelectMenu()) {
      await handleTicketMemberSelect(interaction);
      return;
    }
    if (interaction.isModalSubmit()) {
      await handleTicketModal(client, interaction);
    }
  } catch (error) {
    logError("Discord interaction failed.", {
      userId: interaction.user.id,
      customId: "customId" in interaction ? interaction.customId : undefined,
      commandName: interaction.isChatInputCommand()
        ? interaction.commandName
        : undefined,
      error,
    });

    if (interaction.isRepliable()) {
      const response = {
        content: "تعذر تنفيذ الإجراء. تأكد من صلاحيات البوت وحاول مرة أخرى.",
      };
      if (interaction.deferred || interaction.replied) {
        await interaction
          .followUp({ ...response, flags: MessageFlags.Ephemeral })
          .catch(() => null);
      } else {
        await interaction
          .reply({ ...response, flags: MessageFlags.Ephemeral })
          .catch(() => null);
      }
    }
  }
});

client.on("error", (error) => {
  logError("Discord client error.", { error });
});

process.once("SIGINT", () => {
  logInfo("Shutting down Discord bot after SIGINT.");
  client.destroy();
});

process.once("SIGTERM", () => {
  logInfo("Shutting down Discord bot after SIGTERM.");
  client.destroy();
});

client.login(token).catch((error: unknown) => {
  logError("Discord bot login failed. Check the token and privileged intents.", {
    error,
  });
  process.exitCode = 1;
});