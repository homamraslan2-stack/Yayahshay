type LogFields = Record<string, unknown>;

function write(
  level: "info" | "warn" | "error",
  message: string,
  fields: LogFields = {},
): void {
  const line = JSON.stringify({
    timestamp: new Date().toISOString(),
    level,
    message,
    ...fields,
  });
  (level === "error" ? process.stderr : process.stdout).write(`${line}\n`);
}

export const logInfo = (message: string, fields?: LogFields): void =>
  write("info", message, fields);
export const logWarn = (message: string, fields?: LogFields): void =>
  write("warn", message, fields);
export const logError = (message: string, fields?: LogFields): void =>
  write("error", message, fields);