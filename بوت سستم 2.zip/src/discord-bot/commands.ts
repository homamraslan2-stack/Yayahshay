import {
  ChannelType,
  PermissionFlagsBits,
  SlashCommandBuilder,
} from "discord.js";

const adminPermission = PermissionFlagsBits.Administrator;

export const slashCommands = [
  new SlashCommandBuilder()
    .setName("ticket-setup")
    .setDescription("إعداد لوحة فتح التذاكر")
    .setDefaultMemberPermissions(adminPermission)
    .addChannelOption((option) =>
      option
        .setName("channel")
        .setDescription("القناة التي ستظهر فيها لوحة التذاكر")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true),
    )
    .addRoleOption((option) =>
      option
        .setName("admin-role")
        .setDescription("الرتبة التي تستلم إشعارات التذاكر وتديرها")
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("description")
        .setDescription("وصف لوحة التذاكر")
        .setMaxLength(4000)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("reply-setup")
    .setDescription("تحديد قناة ورسالة الرد التلقائي")
    .setDefaultMemberPermissions(adminPermission)
    .addChannelOption((option) =>
      option
        .setName("channel")
        .setDescription("القناة التي سيرد فيها البوت")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("message")
        .setDescription("نص الرد التلقائي")
        .setMaxLength(2000)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("reply-clear")
    .setDescription("إيقاف الرد التلقائي")
    .setDefaultMemberPermissions(adminPermission),
  new SlashCommandBuilder()
    .setName("autorole-setup")
    .setDescription("تحديد الرتبة التي يحصل عليها العضو الجديد")
    .setDefaultMemberPermissions(adminPermission)
    .addRoleOption((option) =>
      option
        .setName("role")
        .setDescription("الرتبة التلقائية")
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("autorole-clear")
    .setDescription("إيقاف الرتبة التلقائية")
    .setDefaultMemberPermissions(adminPermission),
  new SlashCommandBuilder()
    .setName("welcome-setup")
    .setDescription("تحديد قناة ورسالة الترحيب")
    .setDefaultMemberPermissions(adminPermission)
    .addChannelOption((option) =>
      option
        .setName("channel")
        .setDescription("قناة الترحيب")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("message")
        .setDescription("رسالة الترحيب داخل الإيمبد")
        .setMaxLength(2000)
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("welcome-clear")
    .setDescription("إيقاف رسائل الترحيب")
    .setDefaultMemberPermissions(adminPermission),
  new SlashCommandBuilder()
    .setName("ticket-clear")
    .setDescription("إيقاف لوحة التذاكر الحالية")
    .setDefaultMemberPermissions(adminPermission),
  new SlashCommandBuilder()
    .setName("setup-status")
    .setDescription("عرض إعدادات البوت الحالية في هذا السيرفر")
    .setDefaultMemberPermissions(adminPermission),
].map((command) => command.toJSON());