export default {
  token: "PASTE_YOUR_DISCORD_BOT_TOKEN_HERE",
};